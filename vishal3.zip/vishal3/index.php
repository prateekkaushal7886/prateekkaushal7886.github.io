<!DOCTYPE html>
<html lang="en">
<head>
	<title>Vishal Kumar Singh</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="keywords" >
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css\bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link rel="shortcut icon" type="image/jpg" href="images\profile2.jpg">
<link href="css\style.css" rel="stylesheet" type="text/css" media="all">
<!-- gallery -->
<link type="text/css" rel="stylesheet" href="css\cm-overlay.css">

<!-- //gallery -->
<!-- font-awesome icons -->
<link href="css\font-awesome.css" rel="stylesheet"> 

<!-- //font-awesome icons -->
<link href="//fonts.googleapis.com/css?family=Gidugu" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>


</head>


<body>
	<!-- header -->
	
	<!-- //header -->
	<div class="main" id="home">
		<!-- banner -->
		<div class="banner">
			<!--Slider-->
			<img src="images\profile2.jpg" style="width:250px; height:250px;border-radius: 50%;border: 0px;" alt=" " class="img-responsive">
			<br><h2>Vishal Kumar Singh</h2>
			<span>LET'S START CHANGING THINGS</span>
			<div class="callbacks_container">
				<ul class="rslides" id="slider3">
					<li>
						
						<div class="slider-info">
							<p>Positive Action combined with Positive Thinking results in success.</p>
						</div>
					</li>
					<li>
						<div class="slider-info">

							<p>Leaders don’t create followers, they create more leaders.</p>
						</div>
					</li>
					<li>

						<div class="slider-info">
							<p>The best way to predict the future is to create it.</p>
							
						</div>
					</li>


				</ul>

				<div class="clearfix"></div>
			</div>
			<!--//Slider-->
			<ul class="top-links">
				<li><a href="https://www.facebook.com/profile.php?id=100010338962799"><i class="fa fa-facebook"></i></a></li>
				<li><a href="https://www.linkedin.com/in/vishal-kumar-singh-284a89125/"><i class="fa fa-linkedin"></i></a></li>

			</ul>
		</div>
		<!-- //banner -->
	</div>

	<!-- about -->
	<div class="about" id="about">
		<div class="container">
			<div class="col-md-2"></div><div class="col-md-8">
				<h3 class="w3l_head">About Me</h3>
				<p class="w3ls_head_para"></p>
				<center><p style="text-align: justify;">I am <b> Vishal Kumar Singh </b>, an undergraduate student of the department of <b>Mining Engineering</b>. I am from <b>Gorakhpur</b>, Uttar Pradesh. I have spent almost three years in Kharagpur and a major part of my personality has been moulded her in this beautiful place.<br><br> So in gratitude, I wish to serve the community I reside in. For this I need to walk with all of you together. Please reach out to me if you have any positive criticism or suggestions </p></center>

			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
	<!-- //about-bottom -->
	<!-- services -->
	<div class="service" id="services">
		<div class="container">

			<h3 class="w3l_head two">My KGP Journey</h3>
			<p class="w3ls_head_para"></p>
			<div class="service-agileits">

				<div class="col-md-3 list-gds text-center">
					<img src="images/sac_logo.png" >
					<h4 style="color: #44c7f4">STUDENTS' ALUMNI CELL</h4>
					<p>General Secretary<br>2017-18

					</div>
					<div class="col-md-3 list-gds text-center">
						<img src="images/EY.png" width="100px;" height="100px;">
						<h4 style="color: #44c7f4">ERNST & YOUNG</h4>
						<p>Summer Intern<br>May 2017-June 2017
						</p>
					</div>
					<div class="col-md-3 list-gds text-center">
						<img src="images/rankethon.png" width="100px;" height="100px;">
						<h4 style="color: #44c7f4">RANKETHON</h4>
						<p>
							City Head <br>August 2015-September 2016<br>

						</p>
					</div>
					<div class="col-md-3 list-gds text-center">
						<i class="fa fa-book" aria-hidden="true"></i>
						<h4 style="color: #44c7f4"><br>ACADEMICS</h4>
						<p>  Department Rank 1<br> among Dual Degree students
<br><br>
						</div>
						<div class="clearfix"><br></div>			

					</div>
				</div>
			</div>
			<!-- //services -->
			<!-- /education --><br><br>
			<div class="education" id="education">
				<div class="col-md-2 skills">

				</div>

				<div class="col-md-8 education-w3l">
					<h3 class="w3l_head three" style="font-size: 280%;">Experiences & Initiatives</h3>
					<div class="education-agile-grids">
						<div class="education-agile-w3l">
							<div class="education-agile-w3l-year">
								<h5 style="font-size: 23px;">2017-PRESENT</h5>
								<h6>Students' Alumni Cell<br></h6>
								<br>
								<img src="images/kgplogo.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>General Secretary 
								</center></h4>
								<p>Under my leadership, the 15th Annual Alumni Meet saw more than 300 alumni, highest ever in the past 15 years. Also I have been instrumental in launching two new Programs ACAP and Affinity Program. Through ACAP (Alumni Career Assistance Program) the final and pre-final year students get help from the recent alumni to understand the complex CDC procedure.  Also there is the newly launched Affinity Program which aims at giving exclusive benefits to KGPians. Though in its infant stages, this program has tremendous potential in the long run placing IIT KGP in the elite group of colleges in the world having such a program.</p>

							</div>
							<div class="clearfix"></div>
						</div>
						<div class="education-agile-w3l two">
							<div class="education-agile-w3l-year">
								<h4>2017</h4>
								<h6>2017 Summer Internship<br>

								</h6><br>
								<img src="images/EY.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>Ernst & Young</center></h4>
								<p> I designed information memorandum which is a detailed report and guidelines for investors under the national project of “Make in India”. Using the sharp analytical mind that I developed during my stay in KGP, I studied investment queries from the portal of Ministry of Commerce & Industry to enlist and filter investors’ details. In addition to this I also assisted the advisory team in drafting the final report of potential investment opportunities in “Make in India” project.
								</p>

							</div>
							<div class="clearfix"></div>
						</div>
						<div class="education-agile-w3l">
							<div class="education-agile-w3l-year">
								<h5 style="font-size: 23px;">2016-2017</h5>
								<h6>
									Students’ Alumni Cell<br>
								</h6><br>
								<img src="images/kgplogo.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>Student Member</center></h4>
								<p>I started my association with Students’ Alumni Cell as a student member in 2016. I was in the executive team responsible for conducting the 14th Annual Alumni Meet. It was a highly successful meet with huge Year over Year increase of funds raised through Sponsorship and Registrations of Alumni.</p>

							</div>
							<div class="clearfix"></div>
						</div>
						<div class="education-agile-w3l two">
							<div class="education-agile-w3l-year">
								<h4>2016-2017</h4>
								<h6>
									Rankethon<br>
								</h6>
								<br>
								<img src="images/rankethon.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>Marketing Executive</center></h4>
								<p>I extensively planned a tech-integration program for classes 8 to 12 which led to the establishment of Digital Learning System and Tech Laboratories in schools across Uttar Pradesh. The grooming and exposure enabled the students of those schools to participate in Techkriti, the tech-fest of IIT Kanpur, making them the first and only student team to ever participate in Techkriti.</p>

							</div>
							<div class="clearfix"></div>
						</div>
						<div class="education-agile-w3l two">
							<div class="education-agile-w3l-year">
								<h4>2017-2018</h4>
								<h6>
									Rankethon<br>
								</h6>
								<br>
								<img src="images/kgplogo.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>Alumni Career Assistance Program</center></h4>
								<p>I extensively planned a tech-integration program for classes 8 to 12 which led to the establishment of Digital Learning System and Tech Laboratories in schools across Uttar Pradesh. The grooming and exposure enabled the students of those schools to participate in Techkriti, the tech-fest of IIT Kanpur, making them the first and only student team to ever participate in Techkriti.</p>

							</div>
							<div class="clearfix"></div>
						</div>
<div class="education-agile-w3l two">
							<div class="education-agile-w3l-year">
								<h4>2016-2017</h4>
								<h6>
									Rankethon<br>
								</h6>
								<br>
								<img src="images/kgplogo.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>Yearbook</center></h4>
								<p>I extensively planned a tech-integration program for classes 8 to 12 which led to the establishment of Digital Learning System and Tech Laboratories in schools across Uttar Pradesh. The grooming and exposure enabled the students of those schools to participate in Techkriti, the tech-fest of IIT Kanpur, making them the first and only student team to ever participate in Techkriti.</p>

							</div>
							<div class="clearfix"></div>
						</div>
<div class="education-agile-w3l two">
							<div class="education-agile-w3l-year">
								<h4>2016-2017</h4>
								<h6>
									Rankethon<br>
								</h6>
								<br>
								<img src="images/kgplogo.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>Student Alumni Mentorship Program</center></h4>
								<p>I extensively planned a tech-integration program for classes 8 to 12 which led to the establishment of Digital Learning System and Tech Laboratories in schools across Uttar Pradesh. The grooming and exposure enabled the students of those schools to participate in Techkriti, the tech-fest of IIT Kanpur, making them the first and only student team to ever participate in Techkriti.</p>

							</div>
							<div class="clearfix"></div>
						</div>
<div class="education-agile-w3l two">
							<div class="education-agile-w3l-year">
								<h4>2016-2017</h4>
								<h6>
									Rankethon<br>
								</h6>
								<br>
								<img src="images/kgplogo.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>Affinity Program</center></h4>
								<p>I extensively planned a tech-integration program for classes 8 to 12 which led to the establishment of Digital Learning System and Tech Laboratories in schools across Uttar Pradesh. The grooming and exposure enabled the students of those schools to participate in Techkriti, the tech-fest of IIT Kanpur, making them the first and only student team to ever participate in Techkriti.</p>

							</div>
							<div class="clearfix"></div>
						</div>

						<div class="education-agile-w3l">
							<div class="education-agile-w3l-year">
								<h5 style="font-size: 23px;">2015-2016</h5>
								<h6>

									Rankethon 
								</h6>
								<br>
								<img src="images/rankethon.png" width="95px;">
							</div>
							<div class="education-agile-w3l-info">
								<h4><center>City Head</center></h4>
								<p>I organized Summer Camp of Web and App Development for the first time in schools of Malda and Kanpur. This ignited the young minds of the schools involved and they developed a technical temperament

								</p>

							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<div class="col-md-2 skills">

				</div>
				<div class="clearfix"> </div>
			</div>
			<!-- //education -->
			<!-- /experience -->

			<!-- //experience -->
			<!-- /gallery-->
			<div class="portfolio" id="gallery">
				<div class="container">
					<h3 class="w3l_head">Gallery</h3>
					<p class="w3ls_head_para">
						<div class="agileits_portfolio_grids">
							<div class="col-md-4 agileits_portfolio_grid">
								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\profile2.jpg">
										<img src="images\profile2.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">Office of Alumni Affairs & Interntional Relations</h2>

										</div>
									</a>
								</div>
								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\21.jpg">
										<img src="images\21.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">TOI Article</h2>

										</div>
									</a>
								</div>

							</div>
							<div class="col-md-4 agileits_portfolio_grid">
								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\22.jpg">
										<img src="images\22.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">15th Annual Alumni Meet</h2>

										</div>
									</a>
								</div>
								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\25.jpg">
										<img src="images\25.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">Phonathon 4.0</h2>

										</div>
									</a>
								</div>
								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\27.jpg">
										<img src="images\27.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">Day 1,Annual Alumni Meet</h2>

										</div>
									</a>
								</div>


							</div>
							<div class="col-md-4 agileits_portfolio_grid">
								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\23.jpg">
										<img src="images\23.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">Closing Ceremony,15th AAM</h2>

										</div>
									</a>
								</div>

								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\24.jpg">
										<img src="images\24.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">2018 edition of Volleyball tournament organized by Rajendra Prasad Hall of Residence</h2>

										</div>
									</a>
								</div>
								<div class="agileinfo_portfolio_grid hovereffect">
									<a class="cm-overlay" href="images\26.jpg">
										<img src="images\26.jpg" alt=" " class="img-responsive">
										<div class="overlay">
											<h2 style="color: orange; padding-top:20%;">A day before Meet</h2>

										</div>
									</a>
								</div>
							</div>

							<div class="clearfix"> </div>
						</div>


					</div>
				</div>

				<div class="mail" id="mail">
		<div class="container">
			<h3 class="w3l_head w3l_head1">Contact Me</h3>
			<p class="w3ls_head_para w3ls_head_para1">GIVE YOUR VALUABLE SUGGESTIONS</p>
			<div class="w3_mail_grids">
				<form id="form1">
					<div class="col-md-6 w3_agile_mail_grid">
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" id="input-25" placeholder=" " required="" name="name">
							<label class="input__label input__label--ichiro" for="input-25">
								<span class="input__label-content input__label-content--ichiro">Your Name</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="email" id="input-26" placeholder=" " required="" name="email">
							<label class="input__label input__label--ichiro" for="input-26">
								<span class="input__label-content input__label-content--ichiro">Your Email</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" id="input-27" placeholder=" " required="" name="phone">
							<label class="input__label input__label--ichiro" for="input-27">
								<span class="input__label-content input__label-content--ichiro">Your Phone Number</span>
							</label>
						</span>
						
					</div>
					<div class="col-md-6 w3_agile_mail_grid">
						<textarea name="Message" placeholder="Your Message" required=""></textarea>
						<input type="submit" value="Submit">
					</div>
					<div class="clearfix"> </div>
				</form>
			</div>
		</div>
	</div>

				<footer class="grid">
					<div class="branding">
						<h2>Vishal Kumar Singh</h2>
						<p><i class="fa fa-envelope fa-2x"></i>vishalsingh08.iitkgp@gmail.com</p>

					</div>

					<div class="social" style="padding: 20px;">



						<a href="https://www.facebook.com/profile.php?id=100010338962799" ><i style="padding: 4px;" class="fa fa-facebook fa-2x"></i></a>

						<a href="https://www.instagram.com/vishalsingh5027/?hl=en"><i style="padding: 4px;" class="fa fa-instagram fa-2x"></i></a>
						<a href="https://www.linkedin.com/in/vishal-kumar-singh-284a89125/"><i style="padding: 4px;" class="fa fa-linkedin fa-2x"></i></a>

					</div>


					
			</footer>



			<!-- //footer -->
			<script src="js\jquery-2.2.3.min.js"></script> 
			<!-- skills -->
			<script src="js\pie-chart.js" type="text/javascript"></script>
			<script type="text/javascript">
				$(document).ready(function () {
					$('#demo-pie-1').pieChart({
						barColor: '#44c7f4',
						trackColor: '#fff',
						lineCap: 'round',
						lineWidth: 8,
						onStep: function (from, to, percent) {
							$(this.element).find('.pie-value').text(Math.round(percent) + '%');
						}
					});
					$('#demo-pie-2').pieChart({
						barColor: '#44c7f4',
						trackColor: '#fff',
						lineCap: 'butt',
						lineWidth: 8,
						onStep: function (from, to, percent) {
							$(this.element).find('.pie-value').text(Math.round(percent) + '%');
						}
					});
					$('#demo-pie-3').pieChart({
						barColor: '#44c7f4',
						trackColor: '#fff',
						lineCap: 'square',
						lineWidth: 8,
						onStep: function (from, to, percent) {
							$(this.element).find('.pie-value').text(Math.round(percent) + '%');
						}
					});

					$('#demo-pie-4').pieChart({
						barColor: '#44c7f4',
						trackColor: '#fff',
						lineCap: 'square',
						lineWidth: 8,
						onStep: function (from, to, percent) {
							$(this.element).find('.pie-value').text(Math.round(percent) + '%');
						}
					});
				});
			</script>
			<!-- skills -->	
			<script src="js\responsiveslides.min.js"></script>
			<script>
								// You can also use "$(window).load(function() {"
								$(function () {
								  // Slideshow 4
								  $("#slider3").responsiveSlides({
								  	auto: true,
								  	pager:true,
								  	nav:false,
								  	speed: 500,
								  	namespace: "callbacks",
								  	before: function () {
								  		$('.events').append("<li>before event fired.</li>");
								  	},
								  	after: function () {
								  		$('.events').append("<li>after event fired.</li>");
								  	}
								  });

								});
							</script>
							<!-- js -->
							<script src="js\jquery.tools.min.js"></script>
							<script src="js\jquery.mobile.custom.min.js"></script>
							<script src="js\jquery.cm-overlay.js"></script>
							<script>
								$(document).ready(function(){
									$('.cm-overlay').cmOverlay();
								});
							</script>
							<!-- js files -->



							<script src="js\bars.js"></script>

							<!-- start-smoth-scrolling -->
							<script type="text/javascript" src="js\move-top.js"></script>
							<script type="text/javascript" src="js\easing.js"></script>
							<script type="text/javascript">
								jQuery(document).ready(function($) {
									$(".scroll").click(function(event){		
										event.preventDefault();
										$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
									});
								});
							</script>
							<!-- start-smoth-scrolling -->

							<!-- //js -->
							<script src="js\bootstrap.js"></script>
							<!-- //for bootstrap working -->
							<!-- here stars scrolling icon -->
							<script type="text/javascript">
								$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
				*/

				$().UItoTop({ easingType: 'easeOutQuart' });

			});
		</script>
		<!-- //here ends scrolling icon -->
	</body>
	</html>
	<style type="text/css">
	* {
		margin: 0;
		padding: 0;
	}
	a {
		text-decoration: none;
		color: #eadaa2;

		&:hover {
			color: darken(#eadaa2, 10%);
		}
	}
	.grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		grid-auto-columns: minmax(min-content, auto);
		align-items: center;
		justify-items: center;
		background-color: #333;
		color: #eadaa2;

		@media(max-width:50em) {
			grid-template-columns: 1fr;
			grid-template-rows: repeat(3, 1fr);
			grid-gap: 0;
		}

		i {
			padding: 5px;
		}
	}
	.social {
		@media(max-width:50em) {
			grid-row-start: 1;
		}
	}
	.contact {
		padding: 5px;

		@media(max-width:50em) {
			grid-row-start: 2;
			background-color: darken(#c73e1d, 5%);
		}
	}
	.branding {
		padding: 10px;

		p {
			padding: 5px;
		}

		@media(max-width:50em) {
			grid-row-start: 3;
			text-align: center;
		}
	}
</style>



<script type="text/javascript">
$(function () {
        $('#form1').on('submit', function (e) {
          e.preventDefault();
          $.ajax({
            type: 'post',
            url: 'postdata.php',
            data: $('#form1').serialize(),
            success: function (response) {
               if(response== 0 )
               {
                swal({
  title: "WRONG CAPTCHA!",
  text: "Please re-enter the captcha!",
  icon: "error",
  buttons: true,
  dangerMode: true,
}).then((value) => {
 
});
}
else if(response== 1 )
               {
                swal({
  title: "INCOMPLETE DETAILS!",
  text: "Please fill all the details!",
  icon: "error",
  buttons: true,
  dangerMode: true,
}).then((value) => {
 
});
}
else if(response== 2 )
  {
 swal({
  title: "Thank you!",
  text: "We will get back to you soon!",
  icon: "success",
  buttons: true,
  dangerMode: true,
}).then((value) => {
  //window.location="acap.php";
 
});
//alert(response);
}
else
{
  alert(response);
}
            }
          });
        });
      });
</script> 


